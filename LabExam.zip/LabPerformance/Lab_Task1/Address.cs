﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Task1
{
    class Address
    {
        private string houseNo;
        private string roadNo;
        private string area;
        public Address()
        {
            this.houseNo="";
            this.roadNo="";
            this.area="";
        }
        public Address(string houseNo,string roadNo,string area)
        {
            this.houseNo = houseNo;
            this.roadNo = roadNo;
            this.area = area;
        }
        public string HouseNo
        {
            set
            {
                this.houseNo = value;
            }
            get
            {
                return this.houseNo;
            }
        }
        public string RoadNo
        {
            set
            {
                this.roadNo = value;
            }
            get
            {
                return this.roadNo;
            }
        }
        public string Area
        {
            set
            {
                this.area = value;
            }
            get
            {
                return this.area;
            }
        }
        public void GetAddress()
        {
            Console.WriteLine("House No : " + this.houseNo);
            Console.WriteLine("Road No : " + this.roadNo);
            Console.WriteLine("Area : " + this.area);
        }
    }
}
