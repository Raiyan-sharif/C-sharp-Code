﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Task1
{
    public class Account
    {
        private string accName;
        private int acId;
        private double balance;
        private Address address;
        private static int counter;
  
        public Account()
        {
            this.accName = "";
            this.balance = 0.0;
            this.address = new Address();
        }
        public Account(string accName, double balance, string houseNo, string roadNo, string area)
        {
            this.accName = accName;
            Account.counter += 1;
            this.balance=balance;
            this.address = new Address(houseNo,roadNo,area);
            this.acId = Account.counter;
          
        }
        virtual public void Tnasfer(Account receiver,double amount){
            if (amount > this.balance)
            {
                this.balance -= amount;
                receiver.balance += amount;
            }
            else
            {
            }
        }
        public string AccName
        {
            set
            {
                this.accName = value;
            }
            get
            {
                return this.accName;
            }

        }
        public int AcId
        {
            set
            {
                this.acId = value;
            }
            get
            {
                return this.acId;
            }
        }
        public double Balance
        {
            set
            {
                this.balance = value;
            }
            get
            {
                return this.balance;
            }
        }
        

      
        virtual public void Deposit(double amount)
        {
           
            this.balance += amount;

        }
        virtual public void Withdraw(double amount)
        {
            
            if (amount <= 0.0)
            {
                Console.WriteLine("Invalid request");
              
            }
            else if (this.balance < amount)
            {
                Console.WriteLine("sorry requested withdraw amount is not alloowed");

            }
            else
            {
                this.balance = this.balance - amount;
            }
        }
        public void ShowAccountInfo()
        {
            Console.WriteLine("Account Name : " + this.accName);
            Console.WriteLine("Account ID : " + this.acId);
            Console.WriteLine("Account Balance : " + this.balance);
            Console.WriteLine("Account Address : ");
            address.GetAddress();
            Console.WriteLine();
        }


    }

}