﻿using System;

namespace Lab_Task1
{
    class Employee
    {
        private string name;
        private int id;

        public void SetName(string name)
        {
            this.name = name;
        }
        public void SetId(int id)
        {
            this.id = id;
        }
        public string GetName()
        {
            return this.name;
        }
        public int GetId()
        {
            return this.id;
        }

        
    }
}
