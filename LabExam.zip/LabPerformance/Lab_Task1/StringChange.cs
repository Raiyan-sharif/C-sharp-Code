﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Task1
{
    class StringChange
    {
        public string a; 
        StringChange()
        {
            this.a = "";
        }
        StringChange(string input)
        {
            input = input.ToUpper();
            //char[] chars = input.ToCharArray();

            char[] inputarray = input.ToCharArray();
            Array.Reverse(inputarray);
            input = new string(inputarray);
            //Console.WriteLine(input);
            this.a = input;
        }
    }
}
