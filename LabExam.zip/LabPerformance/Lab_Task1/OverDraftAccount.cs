﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Task1
{
    public class OverDraftAccount : Account
    {
        private readonly double overDraftLimit;
        public OverDraftAccount()
        {
            
        }
        public OverDraftAccount(string accName, double balance,string houseNo, string roadNo, string area, double overDraftLimit) : base(accName, balance,houseNo,roadNo,area)
        {
            this.overDraftLimit = overDraftLimit;
        }
        public void ShowOverDraftAccountInfo()
        {

            //Console.WriteLine("\n************************** Your account **************************");
            Console.WriteLine();
            Console.WriteLine("Your over Draft Limit : " + this.overDraftLimit);
            base.ShowAccountInfo();
            Console.WriteLine();
           
        }
      
        override public void Deposit(double amount)
        {
           
           base.Balance = base.Balance + amount;

        }
        override public void Withdraw(double amount)
        {
           
            if (amount < 0)
            {
                Console.WriteLine("Invalid request");
            }
            else if (base.Balance + this.overDraftLimit < amount)
            {
                Console.WriteLine("you don't have sufficient balance sorry ");
 
            }


            else
            {
                base.Balance = base.Balance - amount;
                Console.WriteLine("Successful Welcome again");
            }
        }
    }
}
