﻿using System;


namespace Lab_Task1
{
    class Triangle
    {
        public int x;
        public int y;
        public int z;
        public void Input()
        {
            Console.Write("Input Length of 1st side of triangle : ");
            x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input Length of 2nd side of triangle : ");
            y = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input Length of 3rd side of triangle : ");
            z = Convert.ToInt32(Console.ReadLine());
        }
        public void ShowInfo()
        {
            Console.WriteLine("Triangle Info****************************");
            Console.WriteLine("1st side of triangle : "+this.x);
            Console.WriteLine("2nd side of triangle : " + this.y);
            Console.WriteLine("3rd side of triangle : " + this.z);
        }
        public void TestTriangle()
        {
            if (this.x == this.y && this.y == this.z && this.x == this.z)
            {
                Console.WriteLine("\nThis Triangle is equilateral");

            }
            else if ((this.x == this.y && this.y != this.z) || (this.y == this.z && this.x != this.z) || (this.z == this.x && this.y != this.z))
            {
                Console.WriteLine("\nThis Triangle is isosceles");
            }
            else
            {
                Console.WriteLine("\nThis Triangle is scalene");
            }
        }
    }
}
