﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Task1
{
    class Program

    {
       /* public void StringChange(string input)
        {
            input = input.ToUpper();
            //char[] chars = input.ToCharArray();

            char[] inputarray = input.ToCharArray();
            Array.Reverse(inputarray);
            input = new string(inputarray);
            Console.WriteLine(input);
        }
        */
        static void Main(string[] args)
        {
            
            Account a = new Account("Raiyan", 5500.0, "225A", "33B", "Mirpur");
            Account a1 = new Account("Sharif", 6000.0, "25A", "3B", "Mirpur");
            a.ShowAccountInfo();
            a1.ShowAccountInfo();
            OverDraftAccount o = new OverDraftAccount("Rony", 5000.0, "125A", "13B", "Mirpur", 500.0);
            o.Withdraw(5600.0);
            o.ShowOverDraftAccountInfo();
           // Program p= new Program();
           // p.StringChange("aiub");

        
        }

    }
    
    
}
