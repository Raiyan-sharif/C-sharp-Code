﻿using System;


namespace Lab_Task1
{
    class Student
    {
        string name;
        string id;
        string department;
        float cgpa;

        public void ShowInfo()
        {
            Console.WriteLine("\n\n****************" + this.name + " this is your info***************");
            Console.WriteLine("Name: "+this.name);
            Console.WriteLine("ID: " + this.id);
            Console.WriteLine("Department: " + this.department);
            Console.WriteLine("CGPA: " + this.cgpa);

        }
        public void Input()
        {
            Console.Write("Input Your Name: ");
            name = Console.ReadLine();
            Console.Write("Input Your ID: ");
            id = Console.ReadLine();
            Console.Write("Input Your department: ");
            department = Console.ReadLine();
            Console.Write("Input Your CGPA: ");
            cgpa = Convert.ToSingle(Console.ReadLine());

        }
        public void SetName(String name)
        {
            this.name = name;
        }
        public void SetId(String id)
        {
            this.id = id;
        }
        public void SetDepartment(String department)
        {
            this.department = department;
        }
        public void SetCgpa(float cgpa)
        {
            this.cgpa = cgpa;
        }


    }
}
