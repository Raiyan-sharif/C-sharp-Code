﻿using System;

namespace DefaultValue
{
    class Program
    {
        static void Main(string[] args)
        {
            byte a=new Byte();
            System.Console.WriteLine(a);
            sbyte b=new SByte();
            System.Console.WriteLine(b);
            short c=new Int16();
            System.Console.WriteLine(c);
            ushort d=new UInt16();
            System.Console.WriteLine(d);
            int e=new Int32();
            System.Console.WriteLine(e);
            uint f=new UInt32();
            System.Console.WriteLine(f);
            long g= new Int64();
            System.Console.WriteLine(g);
            ulong h=new UInt64();
            System.Console.WriteLine(h);
            float i=new Single();
            System.Console.WriteLine(i);
            double j=new Double();
            System.Console.WriteLine(j);
            decimal k=new Decimal();
            System.Console.WriteLine(k);
            bool l=new Boolean();
            System.Console.WriteLine(l);
            char m=new Char();
            System.Console.WriteLine(m);
            
        }
    }
}
