﻿using System;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            System.Console.WriteLine("byte..........................");
            byte x = System.Convert.ToByte(System.Console.ReadLine());
            
            if (x < byte.MinValue || x > byte.MaxValue)
            {
                
                System.Console.WriteLine("error");
            }
                
            else
            {
                System.Console.WriteLine(byte.MinValue);
                System.Console.WriteLine(byte.MaxValue);
                System.Console.WriteLine(x);
            }



            System.Console.WriteLine("Sbyte..........................");
            sbyte y = System.Convert.ToSByte(System.Console.ReadLine());

            if (y < sbyte.MinValue || y > sbyte.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(sbyte.MinValue);
                System.Console.WriteLine(sbyte.MaxValue);
                System.Console.WriteLine(y);
            }
            
            
            System.Console.WriteLine("Short..........................");
            short z = System.Convert.ToInt16(System.Console.ReadLine());

            if (z < short.MinValue || z > short.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(short.MinValue);
                System.Console.WriteLine(short.MaxValue);
                System.Console.WriteLine(z);
            }



            System.Console.WriteLine("UShort..........................");
            ushort a = System.Convert.ToUInt16(System.Console.ReadLine());

            if (a < ushort.MinValue || a > ushort.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(ushort.MinValue);
                System.Console.WriteLine(ushort.MaxValue);
                System.Console.WriteLine(a);
            }



            System.Console.WriteLine("Int..........................");
            int b = System.Convert.ToInt32(System.Console.ReadLine());

            if (b < int.MinValue || b > int.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(int.MinValue);
                System.Console.WriteLine(int.MaxValue);
                System.Console.WriteLine(b);
            }




            System.Console.WriteLine("UInt..........................");
            uint c = System.Convert.ToUInt32(System.Console.ReadLine());

            if (c < uint.MinValue || c > uint.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(uint.MinValue);
                System.Console.WriteLine(uint.MaxValue);
                System.Console.WriteLine(c);
            }





            System.Console.WriteLine("long..........................");
            long d = System.Convert.ToInt64(System.Console.ReadLine());

            if (d < long.MinValue || d > long.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(long.MinValue);
                System.Console.WriteLine(long.MaxValue);
                System.Console.WriteLine(d);
            }




            System.Console.WriteLine("Ulong..........................");
            ulong e = System.Convert.ToUInt64(System.Console.ReadLine());

            if (e < ulong.MinValue || e > ulong.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(ulong.MinValue);
                System.Console.WriteLine(ulong.MaxValue);
                System.Console.WriteLine(e);
            }




            System.Console.WriteLine("Float..........................");
            float f = System.Convert.ToSingle(System.Console.ReadLine());

            if (f < float.MinValue || f > float.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(float.MinValue);
                System.Console.WriteLine(float.MaxValue);
                System.Console.WriteLine(f);
            }




            System.Console.WriteLine("Double..........................");
            double g = System.Convert.ToDouble(System.Console.ReadLine());

            if (g < double.MinValue || y > double.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(double.MinValue);
                System.Console.WriteLine(double.MaxValue);
                System.Console.WriteLine(g);
            }




            System.Console.WriteLine("Decimal..........................");
            decimal h = System.Convert.ToDecimal(System.Console.ReadLine());

            if (h < decimal.MinValue || h > decimal.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(decimal.MinValue);
                System.Console.WriteLine(decimal.MaxValue);
                System.Console.WriteLine(h);
            }



            System.Console.WriteLine("Boolean..........................");
            bool i = System.Convert.ToBoolean(System.Console.ReadLine());

            if (i!=(false) || i !=(true))
            {

                System.Console.WriteLine("error");
            }

            else
            {
                
                System.Console.WriteLine(i);
            }



            System.Console.WriteLine("char..........................");
            char j = System.Convert.ToChar(System.Console.ReadLine());

            if (j < char.MinValue || j> char.MaxValue)
            {

                System.Console.WriteLine("error");
            }

            else
            {
                System.Console.WriteLine(char.MinValue);
                System.Console.WriteLine(char.MaxValue);
                System.Console.WriteLine(j);
            }


        }
    }
}
