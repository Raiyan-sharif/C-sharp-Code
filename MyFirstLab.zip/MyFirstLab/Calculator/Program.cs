﻿
namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
           /* System.Console.Write("Input 1st number: ");
            int ip = System.Convert.ToInt32(System.Console.ReadLine());
            System.Console.Write("Input 2nd number: ");
            int jp = System.Convert.ToInt32(System.Console.ReadLine());
            */
            
            int temp;
            while (true)
            {
                
               
                
                

                    System.Console.WriteLine("\n\nchoose the best option:\n1.Addtion\n2.Subtraction\n3.Multiplication\n4.Divition\n5.Exit");
                    int k = System.Convert.ToInt32(System.Console.ReadLine());
                    if (k == 1)
                    {
                        System.Console.Write("Input 1st number: ");
                        int i = System.Convert.ToInt32(System.Console.ReadLine());
                        System.Console.Write("Input 2nd number: ");
                        int j = System.Convert.ToInt32(System.Console.ReadLine());
                        temp = i + j;
                        System.Console.Clear();
                        System.Console.WriteLine("result: " + temp);

                    }
                    else if (k == 2)
                    {
                        System.Console.Write("Input 1st number: ");
                        int i = System.Convert.ToInt32(System.Console.ReadLine());
                        System.Console.Write("Input 2nd number: ");
                        int j = System.Convert.ToInt32(System.Console.ReadLine());
                        temp = i - j;
                        System.Console.WriteLine("result: " + temp);
                    }
                    else if (k == 2)
                    {
                        System.Console.Write("Input 1st number: ");
                        int i = System.Convert.ToInt32(System.Console.ReadLine());
                        System.Console.Write("Input 2nd number: ");
                        int j = System.Convert.ToInt32(System.Console.ReadLine());
                        temp = i * j;
                        System.Console.WriteLine("result: " + temp);
                    }
                    else if (k == 2)
                    {
                        System.Console.Write("Input 1st number: ");
                        int i = System.Convert.ToInt32(System.Console.ReadLine());
                        System.Console.Write("Input 2nd number: ");
                        int j = System.Convert.ToInt32(System.Console.ReadLine());
                        temp = i / j;
                        System.Console.WriteLine("result: " + temp);
                    }
                    else if (k == 5)
                    {
                        break;
                    }
                    else
                    {
                        System.Console.WriteLine("wrong option");
                    }
                
                
            }
        }
    }
}
