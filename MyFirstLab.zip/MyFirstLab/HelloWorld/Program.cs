﻿namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            
            /*System.Console.Write("Enter your Name: ");
            string Name= System.Console.ReadLine();
            System.Console.Write("Enter your Semester: ");
            int Semester= System.Convert.ToInt32(System.Console.ReadLine());
            System.Console.Write("Enter your school name: ");
            string School= System.Console.ReadLine();
            System.Console.Write("Enter your college name: ");
            string College= System.Console.ReadLine();
            System.Console.Write("Enter your Home District: ");
            string HDi= System.Console.ReadLine();
            System.Console.WriteLine("######################### Your information #########################");
            System.Console.WriteLine("Name : "+Name);
            System.Console.WriteLine("Semester : "+Semester);
            System.Console.WriteLine("School: "+School);
            System.Console.WriteLine("College: "+College);
            System.Console.WriteLine("Home District: "+HDi);*/
            //System.Console.Write("\n\nName : Raiyan Sharif\n"+"Semester : 7th\n"+"School: Milestone college\n"+"College: Milestone college\n"+"Home District: Chittagong\n");*/
            //System.Console.WriteLine("Value of I:"+i);
        }
    }
}
