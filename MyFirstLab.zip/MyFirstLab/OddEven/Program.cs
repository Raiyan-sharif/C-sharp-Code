﻿

namespace OddEven
{
    class Program
    {
        static void Main(string[] args)
        {
            int any = System.Convert.ToInt32(System.Console.ReadLine());
            if (any % 2 != 0)
            {
                System.Console.WriteLine("ODD");
            }
            else
            {
                System.Console.WriteLine("EVEN");
            }
        }
    }
}
