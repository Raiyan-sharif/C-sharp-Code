﻿
namespace Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            /*int x = 10;
            System.Console.WriteLine(++x);
            x = 10;
            System.Console.WriteLine(x++);
            System.Console.WriteLine(x);
            for (x = 0; x < 10; x++)
            {
                System.Console.WriteLine(x);
            }*/
            int x = 10;
            System.Console.WriteLine(++x + x);
            System.Console.WriteLine(x-- +x + ++x);
            System.Console.WriteLine(++x + x + x--);
            System.Console.WriteLine(--x + x++ - x--);
            System.Console.WriteLine(x-- + x + ++x);
        }
    }
}
