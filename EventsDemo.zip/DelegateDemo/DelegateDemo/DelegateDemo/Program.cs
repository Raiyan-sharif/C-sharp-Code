﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    public delegate void Transform(int x);
    class Program
    {
        static void Main(string[] args)
        {
            ////Square(5);
            ////Transform t = new Transform(Square);
            //Transform t = Square;
            ////Multicasting
            //t += Cube;
            //t(5);
            //t -= Square;
            //t(6);
            ////Instantiated Methods
            //Demo d = new Demo();
            //t += d.Test;
            //t(7);
            
            
            Demo d = new Demo();
            //int temp = d.CallbackDemo(6);

            Transform t2 = Receiver;
            d.CallbackDemo(20, t2);

            Transform t3 = new ReceiverDemo().Receiver;
            d.CallbackDemo(10, t3);

            Console.ReadLine();
        }
        static void Square(int i)
        {
            Console.WriteLine("Square of {0} is {1}",i,i*i);
        }
        static void Cube(int j)
        {
            Console.WriteLine("Cube of {0} is {1}", j, j * j*j);
        }
        public static void Receiver(int l)
        {
            Console.WriteLine("Output from callback receiver where received value is:{0}", l);
        }
    }
    class Demo
    {
        public void Test(int k)
        {
            Console.WriteLine("Output from demo class where k is:{0}",k);
        }
        public int CallbackDemo(int x)
        {
            x = x + 6;
            return x;
        }
        public void CallbackDemo(int x, Transform t)
        {
            x = x + 6;
            t(x);
        }
    }

    class ReceiverDemo
    {
        public void Receiver(int l)
        {
            Console.WriteLine("Output from callback receiver where received value is:{0}", l);
        }
    }
}
