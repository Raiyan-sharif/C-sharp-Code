﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Function1();
            //Function2();
            Thread t1 = new Thread(Function1);
            Thread t2 = new Thread(Function2);
            //t1.IsBackground = true;
            //t2.IsBackground = true;
            ////t2.Priority = ThreadPriority.Highest;
            ////t1.Priority = ThreadPriority.Lowest;
            t1.Start();
            t2.Start();

            ////Function1();
            ////Function2();
            //Thread.Sleep(1000);
            Console.WriteLine("Main Thread exit");
        }

        static void Function1()
        {
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(100);
                Console.WriteLine("Function 1 Value " + i);
            }
            Console.WriteLine("Thread 1 exit");
        }
        static void Function2()
        {
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(100);
                Console.WriteLine("Function 2 Value " + i);
            }
            Console.WriteLine("Thread 2 exit");
        }
        
    }
}
