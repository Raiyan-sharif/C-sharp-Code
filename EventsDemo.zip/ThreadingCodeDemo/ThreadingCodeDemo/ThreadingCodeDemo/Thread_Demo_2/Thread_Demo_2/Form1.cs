﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Thread_Demo_2
{
    public partial class Form1 : Form
    {
        public delegate void  demoDelegate(Button btn);
        Random random;
        public Form1()
        {
            InitializeComponent();
        }

        private void Thread1(object thread1Button)
        {
            for (int i=0; i < 100; i++)
            {
                Thread.Sleep(10);
                this.CreateGraphics().
                    DrawRectangle(new Pen(Brushes.Red,2),
                    new Rectangle(i+random.Next(this.Width),
                        i+random.Next(this.Height),20,20));
            }                        
            //btnThread1.Enabled = true;            

            if (btnThread1.InvokeRequired)
            {
                demoDelegate d = new demoDelegate(EnableButton);
                this.Invoke(d, new object[] { btnThread1 });
            }
        }
        private void Thread2(object thread2Button)
        {
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(100);
                this.CreateGraphics().DrawRectangle(new Pen(Brushes.Blue, 2),
                    new Rectangle(i + random.Next(this.Width),
                        i + random.Next(this.Height), 20, 20));
            }
            //btnThread2.Enabled = true;

            if (btnThread2.InvokeRequired)
            {
                demoDelegate d = new demoDelegate(EnableButton);
                this.Invoke(d, new object[] { btnThread2 });
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            random = new Random();
        }

        private void btnThread1_Click(object sender, EventArgs e)
        {
            btnThread1.Enabled = false;
            Thread t1 = new Thread(Thread1);
            t1.Start();
        }

        private void btnThread2_Click(object sender, EventArgs e)
        {
            btnThread2.Enabled = false;
            Thread t2 = new Thread(Thread2);
            t2.Start();
        }

        public void EnableButton(Button btn)
        {
            btn.Enabled = true;
        }
    }
}
