﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace BackgroundWorker_Demo
{
    public partial class Form1 : Form
    {
        BackgroundWorker worker;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            worker = new BackgroundWorker();
            worker.DoWork+=new DoWorkEventHandler(worker_DoWork);
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted); 
            worker.ProgressChanged+=new ProgressChangedEventHandler(worker_ProgressChanged);

            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;
        }

        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i < 100; i++)
            {
                if (worker.CancellationPending)
                {
                    e.Cancel = true;
                    worker.ReportProgress(0);                    
                    return;
                }
                Thread.Sleep(100);
                worker.ReportProgress(i);                   
            }
            worker.ReportProgress(100);
        }

        private void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            lblStatus.Text = "Processing..." + e.ProgressPercentage.ToString();
            progressBar1.Value = e.ProgressPercentage;
        }

        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                lblStatus.Text = "Work Cancelled";
                return;
            }

            if (e.Error!=null)
            {
                lblStatus.Text = "Error occured while working..."+e.Error.Message;
                return;
            }

            lblStatus.Text = "Work Completed";

            btnStartWork.Enabled = true;
            btnCancelWork.Enabled = false;
        }

        private void btnStartWork_Click(object sender, EventArgs e)
        {
            btnStartWork.Enabled = false;
            btnCancelWork.Enabled = true;

            worker.RunWorkerAsync();

        }

        private void btnCancelWork_Click(object sender, EventArgs e)
        {
            if (worker.WorkerSupportsCancellation)
            {
                worker.CancelAsync();
                btnCancelWork.Enabled = false;
                btnStartWork.Enabled = true;
            }
        }


        
    }
}
