﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Stock s = new Stock("ABBANK");
            s.Price = 27;
            //PriceChangeHandler handler = s_PriceChanged;
            s.PriceChanged += s_PriceChanged;
           
            s.Price = 37;

            Console.ReadLine();
        }

        static void s_PriceChanged(double op, double p)
        {
            Console.WriteLine("Old Price:{0}, New Price:{1}",op,p);
        }
    }
}
