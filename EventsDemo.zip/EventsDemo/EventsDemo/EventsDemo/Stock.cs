﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsDemo
{    
    public delegate void PriceChangeHandler(double op,double p);
 
    class Stock
    {
        string name;
        double price;
        public event PriceChangeHandler PriceChanged;

        public Stock(string n)
        {
            name = n;
        }
        public double Price 
        {
            get
            {
                return price;
            }
            set
            {
                if (price == value)
                    return;
                double oldprice = price;
                price = value;

                if (PriceChanged != null)
                {
                    PriceChanged(oldprice, price);
                }
            }
        }
    }
}
